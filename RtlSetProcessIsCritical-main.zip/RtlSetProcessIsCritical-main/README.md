# RtlSetProcessIsCritical
setting a process as critical!


# CREATED USING VISUAL STUDIO 2019
