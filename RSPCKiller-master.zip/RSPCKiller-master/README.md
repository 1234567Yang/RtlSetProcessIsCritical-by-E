# Overview
* Disable RtlSetProcessIsCritical From specific Process using NtSetInformationProcess by loading DLL into the target process
# DEMO:

![DEMO](https://github.com/ZeroM3m0ry/BypassRtlSetProcessIsCritical/blob/master/DEMO.gif)

